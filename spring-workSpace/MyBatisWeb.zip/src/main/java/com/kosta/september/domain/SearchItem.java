package com.kosta.september.domain;

public class SearchItem {
	public static final int DEFAULT_PAGE_SIZE = 10;
	
	private int page = 1;					// 현재 페이지 
	private int pageSize = DEFAULT_PAGE_SIZE;	// 한 페이지당 게시물 건수 
	private String option = "";
	private String keyword = "";
	
	public SearchItem() {}

	public SearchItem(int page, int pageSize) {
		//super();
		this(page, pageSize, "", "");
	}

	public SearchItem(int page, int pageSize, String option, String keyword) {
		//super();
		this.page = page;
		this.pageSize = pageSize;
		this.option = option;
		this.keyword = keyword;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public String getOption() {
		return option;
	}

	public void setOption(String option) {
		this.option = option;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	
	
	
	
}
